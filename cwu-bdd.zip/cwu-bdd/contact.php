<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Istria 1 free template</title>
<meta property="og:url" content="http://www.valeron.net/index.html" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Free responsive web template Istria - Contact" />
<meta property="og:description" content="Free responsive web template Istria by Valeron design studio - Contact" />
<meta property="og:image" content="http://www.valeron.net/img/valeron-artist.jpg" />
<meta name="description" content="Free responsive web template Istria by Valeron design studio - Contact" />
<meta name="msapplication-tap-highlight" content="no" />
<meta name="robots" content="index,follow,all" />
<meta name="keywords" content="Izrada web stranica, web studio Istra" />
<meta name="author" content="Valeron design studio" />
<link rel="apple-touch-icon" sizes="57x57" href="img/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="img/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="img/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="img/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="img/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="img/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="img/apple-touch-icon-180x180.png">
<link rel="icon" type="image/png" href="img/favicon-32x32.png" sizes="32x32">
<link rel="icon" type="image/png" href="img/android-chrome-192x192.png" sizes="192x192">
<link rel="icon" type="image/png" href="img/favicon-96x96.png" sizes="96x96">
<link rel="icon" type="image/png" href="img/favicon-16x16.png" sizes="16x16">
<link rel="manifest" href="img/manifest.json">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-TileImage" content="img/mstile-144x144.png">
<meta name="theme-color" content="#ffffff">
<link rel="stylesheet" href="css/animsition.min.css">
<link rel="stylesheet" type="text/css" href="css/grid.min.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/menu.css" />
<link rel="stylesheet" type="text/css" href="css/social.css" />
<link rel="stylesheet" type="text/css" href="css/slickform.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.1/animate.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome-animation/0.0.8/font-awesome-animation.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
</head>
<body>
<div class="animsition-overlay">
  <div class="horBar2Bxx wow fadeInLeftBig" data-wow-duration="3s"></div>
  <header class="main_h">
    <div class="menufix"> <a class="logo" href="index.html"><img src="images/logo-sample.png" alt="Hello"></a>
      <div class="mobile-toggle"> <span></span> <span></span> <span></span> </div>
      <nav>
        <ul>
          <li class="line"><a class="out animsition-link" href="index.html">HOME</a></li>
          <li class="line"><a class="out animsition-link" href="company.html">COMPANY</a></li>
          <li class="line"><a class="out animsition-link" href="service.html">SERVICES</a></li>
          <li class="line"><a class="out animsition-link" href="blog.html">BLOG</a></li>
          <li class="line"><a class="out animsition-link" href="gallery.html">GALLERY</a></li>
          <li><a class="out active animsition-link" href="contact.html">CONTACT</a></li>
        </ul>
      </nav>
    </div>
    <!-- / row --> 
    
  </header>
  <div class="grid flex16">
    <div class="row">
      <div class="colw_6">
        <h1 id="title-sub1">Free web template Istria</h1>
        <h2 id="title-sub2">CONTACT US</h2>
      </div>
      <!-- END colw_6 -->
      
      <div class="col_6">
        <div class="box-fix">
          <h3 class="centered">Find us on social media</h3>
          <div class="social"> <a href="https://www.facebook.com/Valeron-design-studio-245216518822368/" class="soc-btn facebook"><i class="fa fa-facebook"></i>Facebook</a> <a href="https://twitter.com/ds_valeron" class="soc-btn twitter"><i class="fa fa-twitter"></i>Twitter</a> <a href="https://plus.google.com/116499013539302933204" class="soc-btn google5"><i class="fa fa-google"></i>Google +</a> </div>
        </div>
      </div>
      <!-- END col_6 --> 
      
    </div>
    <!-- END row --> 
    
  </div>
  <!-- End GRID FLEX16 -->
  
  <div class="grid">
    <div class="row paddtop100">
      <div class="col_12">
        <h2 class="title-small center">We love working with clients who love to standout from the crowd</h2>
        <h3 class="title-gray center">Lorem ipsum dolor sit amet nesciunt eos</h3>
      </div>
      <!-- END col_12 -->
      
      <div class="colw_6 spec-l-cont border-right">
        <h3>Contact Info</h3>
        <ul class="contact">
          <li>454 Street Name, Address, City <span><i class="fa fa-map-marker"></i></span></li>
          <li>+1 (555) 543-4567 <span><i class="fa fa-phone"></i></span></li>
          <li>+1 (555) 543-4568 <span><i class="fa fa-fax"></i></span></li>
          <li>support@domain.com <span><i class="fa fa-envelope"></i></span></li>
          <li>Monday - Friday 9:00 - 21:00 <span><i class="fa fa-clock-o"></i></span></li>
        </ul>
        <hr />
        <a href="http://goo.gl/maps/HCFZl"><img src="img/google-map.jpg" alt="Google Maps" class="full-width"></a> </div>
      <!-- END col_6 -->
      
      <div class="colw_6 paddbott100 spec-r-cont">
        <h3>Contact Form</h3>
        <div class="slickwrap">
          <div class="slickreporting">
            <div class="successcontainer"></div>
            <div class="errorcontainer">
              <div class="errorshutter"></div>
              <div class="slickerror"></div>
            </div>
          </div>
          <form method="post" id="slickform" action="javascript:slickcontactparse();">
            <fieldset>
              <label><span>*</span>Name</label>
              <input id="name" name="name" type="text" value="">
              <br />
              <label><span>*</span>Phone</label>
              <input id="phone" name="phone" type="text" value="">
              <br />
              <label><span>*</span>Email</label>
              <input id="email" name="email" type="text" value="">
              <br />
              <label><span>*</span>Comment</label>
              <textarea name="comment" id="comment" cols="5" rows="5" class="largertextarea"></textarea>
              <h3>Are You Human?</h3>
              <br />
              <label><span>*</span> 12 + 3</label>
              <input name="human" id="human" type="text" value="" class="areyouhuman">
              <hr />
              <input name="submit" type="submit" value="Contact Us" class="slickbutton">
            </fieldset>
          </form>
        </div>
      </div>
      <!-- END col_6 --> 
      
    </div>
    <!-- END row --> 
    
  </div>
  <!-- End GRID FLEX16 -->
  
  <div class="grid">
    <div class="row paddbott100">
      <div class="col_6">
        <h6>Facilis nesciunt eos ipsum id Facilis nesciunt eos</h6>
        <p>Architecto velit sequi fuga minima commodi, porro vitae officiis, minus voluptates ab. Dolore, dolor repellat quasi. Facilis nesciunt eos, ipsum id, architecto velit sequi, porro vitae officiis, voluptatibus minus voluptates ab. </p>
      </div>
      <!-- END col_6 -->
      
      <div class="col_6">
        <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</h6>
        <p>Architecto velit sequi fuga minima commodi, porro vitae officiis, minus voluptates ab. Dolore, dolor repellat quasi. Facilis nesciunt eos, ipsum id, architecto velit sequi, porro vitae officiis, voluptatibus minus voluptates ab. Dolore, <a href="#">dolor repellat quasi</a>.</p>
      </div>
      <!-- END col_6 --> 
      
    </div>
    <!-- END row -->
    
    <p class="dolje">2005 - <script>document.write(new Date().getFullYear())</script> Valeron design studio | Izrada web stranica <a href="http://www.valeron.net" class="linkline">VALERON design studio</a></p>
  </div>
  <!-- End GRID --> 
</div>
<!-- END .animsition-overlaj --> 

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script type="text/javascript" src="js/jquery.matchHeight-min.js"></script> 
<script src="js/wow.min.js"></script> 
<script src="js/animsition.min.js"></script> 
<script src="js/Slickform.js"></script> 
<script src="js/functions.js"></script> 
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-15815880-3']);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
</body>
</html>