<?php if($showcookie) { ?>
<div class="notification-box">
	<div id="cookie_box" class="item cookie-alert">
		<p>En poursuivant votre navigation sur ce site, vous acceptez l’utilisation de cookies dans le but d'améliorer votre expérience utilisateur.</p><a class="button special" href="accept_cookie.php">OK, J'accepte</a>
	</div>
</div>
<?php } ?>